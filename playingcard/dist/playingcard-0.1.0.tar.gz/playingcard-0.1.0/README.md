# PlayingCard
Reusable model for a playing card.
A deck of cards can be used to play poker.


