# -*- coding: utf-8 -*-

from .playingcard import PlayingCard

__version__ = '0.1.0'
VERISON = __version__
